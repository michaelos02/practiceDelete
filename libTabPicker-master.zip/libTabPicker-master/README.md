# Library for Hiding and Showing Tabs in a Spreadsheet

Working with big spreadsheets I found myself having to hide and un-hide many tabs at once.  This is what prompted this library.

## Do note the following:

*The below will need to be added to the container spreadsheet (it can also be found in NOTE.js)*
```javascript
/**
 * Need to add this code as a library and DON"T change the name
 * 
 * In the container spreadsheet this code must be added somewhere:
 * /
 function onOpen() {
  libTabPicker.onOpen();
}

//This is for a "normal" Library.Namespace.Method call
function callLibrary3(func, args){
    console.log("callLibrary from sheet scripts")
    var arr = func.split(".");

    var libName = arr[0];
    var nsName = arr[1];
    var nsFunc  = arr[2]

    args = args || [];

   return this[libName][nsName][nsFunc].apply(this, args);

}
```

